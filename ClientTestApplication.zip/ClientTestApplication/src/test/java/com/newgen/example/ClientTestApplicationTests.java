package com.newgen.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
