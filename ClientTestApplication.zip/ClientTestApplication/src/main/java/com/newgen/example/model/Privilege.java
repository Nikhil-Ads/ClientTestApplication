package com.newgen.example.model;

public enum Privilege {
	
	INHERITED, PRIVATE, SHARED
}
