package com.newgen.example.model;

public enum Flag {
	
	COMMITED, UNCOMMITED
}
