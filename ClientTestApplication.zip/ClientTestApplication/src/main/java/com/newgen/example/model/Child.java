/**
 * 
 */
package com.newgen.example.model;

/**
 * @author nikhil.adlakha
 *
 */
public class Child {

}
