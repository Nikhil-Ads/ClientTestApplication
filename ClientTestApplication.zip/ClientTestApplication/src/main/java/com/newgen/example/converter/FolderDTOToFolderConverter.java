package com.newgen.example.converter;

import org.springframework.core.convert.converter.Converter;

import com.newgen.example.dto.FolderDTO;
import com.newgen.example.model.Folder;

public class FolderDTOToFolderConverter implements Converter<FolderDTO, Folder> {

	@Override
	public Folder convert(FolderDTO source) {
		// TODO Auto-generated method stub
		return null;
	}

}
