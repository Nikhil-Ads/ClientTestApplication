package com.newgen.example.model;

public enum ChildType {
	
	FOLDER, CONTENT

}
