package com.newgen.example.config;

/*
 * @Configuration
 * 
 * @EnableSwagger2 public class SwaggerConfig {
 * 
 * @Value("${version}") private String version;
 * 
 * // @Bean // public Docket usersApi() { // return new
 * Docket(DocumentationType.SWAGGER_2) // .groupName("cabinet_service") //
 * .host("localhost:8183") // .apiInfo(apiInfo()) // .select() //
 * .apis(RequestHandlerSelectors.any()) // .paths(paths()) // .build(); // } //
 * // @SuppressWarnings("unchecked") // private Predicate<String> paths() { //
 * return or(regex("/cabinets.*") ); // }
 * 
 * private ApiInfo apiInfo() { return new ApiInfoBuilder()
 * .title("Cabinet Service")
 * .description("Library Service for managing cabinets on ECM Server") //
 * .termsOfServiceUrl("http://www.opencredo.com") .contact(new
 * Contact("Anushree Jain", "", "anushree.jain@newgen.co.in"))
 * //.license("Apache License Version 2.0")
 * //.licenseUrl("https://github.com/springfox/springfox/blob/master/LICENSE")
 * .version(version) .build(); } }
 */
