package com.newgen.example.error.constants;

public class CabinetErrorConstants {

		public static final String PREFIX = "1900";
		
		public static final String ERROR_IN_CREATING_NEW_CABINET = "1";
		public static final String INVALID_CABINET_ID = "2";
}
