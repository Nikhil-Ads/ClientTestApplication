package com.newgen.example.controller;

import java.io.IOException;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.newgen.example.constants.Constants;
import com.newgen.example.exception.CustomException;
import com.newgen.example.service.FolderFetchService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Validated
@RequestMapping(value = "/folders/fetch")
public class FolderFetchController extends ExceptionThrower implements Constants {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FolderFetchController.class);
	
	@Autowired
	private FolderFetchService folderFetchService;	
	
	@GetMapping("/{id}")
	@ApiOperation(value = "Fetches the list of child elements in a folder ", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(code = HttpStatus.OK)
	public ResponseEntity<String> fetchFolder(
			@PathVariable("id") 
			@NotEmpty(message = "Folder Id must not be empty")
			@Pattern(regexp = "^[a-zA-Z0-9]+$", message = "Folder Id is not Valid")
			String parentFolderId,
			@ApiParam("TenantId of the Tenant. It can be copied from 'Tenant ID' textbox from Documentation and Try-Out above.")
			@Valid @RequestHeader(value = "tenantId") String tenantId,
			@ApiParam("UserId of the user initiating the request.")
			@RequestHeader(value = "userId", required = false) String userId,
			@ApiParam("Sorting Order in which you want the list to be sorted in. [ASCENDING|DESCENDING]")
			@RequestHeader(value = "sortOrder", required = false) String sortOrder,
			@ApiParam("Field Name, based on which you want to sort the list")
			@RequestHeader(value = "sortOn", required = false) String sortOn,
			@ApiParam("Offset by which you want to start getting the folders, inside the parent folder.")
			@RequestHeader(value = "folderOffset", required = false) String folderOffset,
			@ApiParam("Offset by which you want to start getting the documents, inside the parent folder.")
			@RequestHeader(value = "contentOffset", required = false) String contentOffset,
			@ApiParam("Maximum size of list, you want to get")
			@RequestHeader(value = "limit", required = false) String limit) 
	throws CustomException, JsonParseException, JsonMappingException, JSONException, IOException {
		LOGGER.debug("Entering Fetch Folder");
		String responseStr=null;
		
		if (tenantId == null || !StringUtils.isAlphanumeric(tenantId)) 
				throwInvalidTenantException();
		else 	responseStr = folderFetchService.fetchFolder(parentFolderId, tenantId, userId, sortOrder, sortOn, folderOffset, contentOffset, limit);					

		//Finally
		LOGGER.debug("Exiting Fetch Folder Service");
		return new ResponseEntity<String>(responseStr, HttpStatus.OK);		
	}
	
	@PostMapping("/")
	public String test(
			@NotNull 
			
			MultipartFile file) {
		return null;
	}
}

/*Scraps for FolderFetchController
 * 
 * 	
	@GetMapping("/contents")
	public Content getContent(@RequestBody Content content) {
		LOGGER.info("Content Passed : "+content);
		return content;
	}
	
	@GetMapping("/content")
	public ContentDTO getContents(@RequestBody ContentDTO content) {
		LOGGER.info("Content Passed : "+content);
		return content;
	}	
 * 
 * fetchFolder(...){
 * 		if (tenantId == null || !StringUtils.isAlphanumeric(tenantId)) {
			throwInvalidTenantException();
		}
		if (folderService.findById(parentFolderId, tenantId, userId) == null)
			throwFolderNotFoundException();
		else {
			List<ChildDTO> childDTO = new ArrayList<>();
			//Getting All Folders inside the Parent Folder
			if(!folderService.isFolderEmpty(parentFolderId, tenantId)) {
				folderService.listFoldersUnderParentFolderId(parentFolderId, tenantId).forEach((Folder folder) -> {folderToFolderDTOConverter.convert(folder);});
			 	}
			//Getting All Contents inside the Parent Folder
			
			return new ResponseEntity<List<ChildDTO>>(childDTO,HttpStatus.OK);
		}
		return null;
 * }*/
