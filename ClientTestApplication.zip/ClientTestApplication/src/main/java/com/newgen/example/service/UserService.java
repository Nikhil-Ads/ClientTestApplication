package com.newgen.example.service;

import org.springframework.stereotype.Service;

@Service
public interface UserService {
}
