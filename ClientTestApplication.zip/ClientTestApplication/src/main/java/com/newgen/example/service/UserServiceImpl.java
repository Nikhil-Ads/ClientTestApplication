package com.newgen.example.service;

import org.springframework.beans.factory.annotation.Value;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserServiceImpl implements UserService {

	@Value("")
	private String addUser_url;
	
	
	public String addUser() {
		
		return null;
	}
}
